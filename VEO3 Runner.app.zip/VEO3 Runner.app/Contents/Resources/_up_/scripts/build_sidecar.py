#!/usr/bin/env python3
"""
Build script để đóng gói Python automation thành standalone executable.

Sử dụng PyInstaller để bundle Python + Playwright + tất cả dependencies
thành một file binary duy nhất, không cần cài Python trên máy khác.

Usage:
    python build_sidecar.py [--target TARGET]
    
Targets:
    aarch64-apple-darwin    - macOS Apple Silicon (M1/M2/M3)
    x86_64-apple-darwin     - macOS Intel
    x86_64-pc-windows-msvc  - Windows 64-bit
    x86_64-unknown-linux-gnu - Linux 64-bit
"""

import argparse
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

# Mapping Tauri target -> PyInstaller target
TARGET_MAP = {
    "aarch64-apple-darwin": "darwin-arm64",
    "x86_64-apple-darwin": "darwin-x86_64",
    "x86_64-pc-windows-msvc": "win-amd64",
    "x86_64-unknown-linux-gnu": "linux-x86_64",
}

def get_current_target() -> str:
    """Detect current platform target"""
    system = platform.system().lower()
    machine = platform.machine().lower()
    
    if system == "darwin":
        if machine == "arm64":
            return "aarch64-apple-darwin"
        return "x86_64-apple-darwin"
    elif system == "windows":
        return "x86_64-pc-windows-msvc"
    elif system == "linux":
        return "x86_64-unknown-linux-gnu"
    
    raise RuntimeError(f"Unsupported platform: {system} {machine}")


def get_output_name(target: str) -> str:
    """Generate output binary name với target suffix cho Tauri sidecar"""
    # Tauri sidecar naming convention: name-target[.exe]
    base_name = "veo-automation"
    
    if "windows" in target:
        return f"{base_name}-{target}.exe"
    return f"{base_name}-{target}"


def build_sidecar(target: str, scripts_dir: Path) -> Path:
    """
    Build Python script thành standalone executable.
    
    Returns:
        Path to output binary
    """
    output_name = get_output_name(target)
    output_dir = scripts_dir.parent / "src-tauri" / "binaries"
    output_path = output_dir / output_name
    
    # Tạo thư mục output
    output_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"🔨 Building sidecar for target: {target}")
    print(f"📁 Output: {output_path}")
    
    # PyInstaller command
    pyinstaller_args = [
        sys.executable, "-m", "PyInstaller",
        "--onefile",                          # Single file output
        "--name", output_name.replace(".exe", ""),  # Output name
        "--distpath", str(output_dir),        # Output directory
        "--workpath", str(scripts_dir / "build"),   # Work directory
        "--specpath", str(scripts_dir / "build"),   # Spec file location
        "--clean",                            # Clean before build
        "--noconfirm",                        # Don't ask confirmation
        # Hidden imports cho Playwright
        "--hidden-import", "playwright",
        "--hidden-import", "playwright.async_api",
        "--hidden-import", "playwright._impl",
        # Collect all Playwright data
        "--collect-all", "playwright",
        # Entry point
        str(scripts_dir / "main.py"),
    ]
    
    print(f"🚀 Running: {' '.join(pyinstaller_args)}")
    
    try:
        subprocess.run(pyinstaller_args, check=True, cwd=scripts_dir)
    except subprocess.CalledProcessError as e:
        print(f"❌ PyInstaller failed: {e}")
        sys.exit(1)
    
    # Verify output exists
    if not output_path.exists():
        # PyInstaller có thể không thêm suffix, check lại
        alt_path = output_dir / output_name.split("-" + target)[0]
        if alt_path.exists():
            shutil.move(str(alt_path), str(output_path))
    
    if output_path.exists():
        print(f"✅ Sidecar built successfully: {output_path}")
        
        # Make executable on Unix
        if not sys.platform.startswith("win"):
            os.chmod(output_path, 0o755)
        
        return output_path
    else:
        print(f"❌ Output not found: {output_path}")
        sys.exit(1)


def install_playwright_browsers():
    """Install Playwright browsers (Chromium)"""
    print("📦 Installing Playwright Chromium browser...")
    try:
        subprocess.run([
            sys.executable, "-m", "playwright", "install", "chromium"
        ], check=True)
        print("✅ Chromium installed")
    except subprocess.CalledProcessError as e:
        print(f"⚠️ Warning: Could not install Chromium: {e}")


def main():
    parser = argparse.ArgumentParser(description="Build VEO automation sidecar")
    parser.add_argument(
        "--target", "-t",
        default=get_current_target(),
        choices=list(TARGET_MAP.keys()),
        help="Target platform"
    )
    parser.add_argument(
        "--install-browsers",
        action="store_true",
        help="Install Playwright browsers before building"
    )
    
    args = parser.parse_args()
    scripts_dir = Path(__file__).parent.resolve()
    
    # Check PyInstaller is installed
    try:
        import PyInstaller
        print(f"📦 PyInstaller version: {PyInstaller.__version__}")
    except ImportError:
        print("❌ PyInstaller not installed. Run: pip install pyinstaller")
        sys.exit(1)
    
    # Install browsers if requested
    if args.install_browsers:
        install_playwright_browsers()
    
    # Build sidecar
    output_path = build_sidecar(args.target, scripts_dir)
    
    print("\n" + "="*60)
    print("📋 NEXT STEPS:")
    print("="*60)
    print(f"1. Sidecar binary created at: {output_path}")
    print("2. Tauri will automatically bundle this with your app")
    print("3. Run 'npm run tauri build' to create final app bundle")
    print("")
    print("⚠️  NOTE: Playwright browsers are NOT bundled!")
    print("    Users need to run once: playwright install chromium")
    print("    Or implement auto-install in your app")


if __name__ == "__main__":
    main()
