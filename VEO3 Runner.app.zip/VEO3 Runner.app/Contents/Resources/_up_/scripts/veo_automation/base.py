"""
Base classes cho VEO Automation

BaseAction: Abstract base class cho tất cả actions
ActionResult: Wrapper cho kết quả trả về
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from typing import Any, Optional, TYPE_CHECKING
from datetime import datetime
import json

if TYPE_CHECKING:
    from .browser import BrowserManager


@dataclass
class ActionResult:
    """
    Kết quả trả về từ một action.
    
    Được serialize thành JSON để gửi về Rust backend.
    """
    success: bool
    action: str
    data: dict = field(default_factory=dict)
    error: Optional[str] = None
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def to_json(self) -> str:
        """Convert to JSON string với markers cho Rust parsing"""
        return json.dumps(asdict(self), ensure_ascii=False, indent=2)
    
    def to_marked_json(self) -> str:
        """Convert to JSON với markers để Rust dễ parse"""
        json_str = self.to_json()
        return f"===RESULT_START===\n{json_str}\n===RESULT_END==="
    
    @classmethod
    def success_result(cls, action: str, data: dict) -> "ActionResult":
        """Factory method cho success result"""
        return cls(success=True, action=action, data=data)
    
    @classmethod
    def error_result(cls, action: str, error: str) -> "ActionResult":
        """Factory method cho error result"""
        return cls(success=False, action=action, error=error)


class BaseAction(ABC):
    """
    Abstract base class cho tất cả VEO automation actions.
    
    Mỗi action phải implement method execute() để thực hiện
    thao tác cụ thể trên browser.
    """
    
    # Tên action, override trong subclass
    ACTION_NAME: str = "base"
    
    def __init__(self, browser_manager: "BrowserManager"):
        """
        Khởi tạo action với browser manager.
        
        Args:
            browser_manager: BrowserManager instance đã khởi tạo
        """
        self.browser = browser_manager
        self.page = browser_manager.page
        self._start_time: Optional[datetime] = None
    
    @abstractmethod
    async def execute(self, **kwargs) -> ActionResult:
        """
        Thực hiện action.
        
        Override method này trong subclass để implement logic cụ thể.
        
        Returns:
            ActionResult với success/error status và data
        """
        pass
    
    def log(self, message: str, level: str = "info", **extra) -> None:
        """
        Log message ra stdout dạng JSON.
        
        Args:
            message: Nội dung log
            level: Log level (info, warn, error, debug)
            **extra: Các field bổ sung
        """
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "level": level,
            "action": self.ACTION_NAME,
            "message": message,
            **extra
        }
        print(json.dumps(log_entry, ensure_ascii=False), flush=True)
    
    def log_info(self, message: str, **extra) -> None:
        """Log info level"""
        self.log(message, "info", **extra)
    
    def log_warn(self, message: str, **extra) -> None:
        """Log warning level"""
        self.log(message, "warn", **extra)
    
    def log_error(self, message: str, **extra) -> None:
        """Log error level"""
        self.log(message, "error", **extra)
    
    def log_debug(self, message: str, **extra) -> None:
        """Log debug level"""
        self.log(message, "debug", **extra)
    
    async def safe_execute(self, **kwargs) -> ActionResult:
        """
        Wrapper execute() với error handling.
        
        Tự động catch exceptions và trả về error result.
        """
        self._start_time = datetime.now()
        self.log_info(f"Starting action: {self.ACTION_NAME}")
        
        try:
            result = await self.execute(**kwargs)
            
            # Log execution time
            elapsed = (datetime.now() - self._start_time).total_seconds()
            self.log_info(
                f"Action completed: {self.ACTION_NAME}",
                elapsed_seconds=elapsed,
                success=result.success
            )
            
            return result
            
        except Exception as e:
            self.log_error(f"Action failed: {str(e)}")
            return ActionResult.error_result(
                action=self.ACTION_NAME,
                error=str(e)
            )
    
    async def wait_for_navigation(self, timeout: int = 30000) -> None:
        """Helper: Đợi page navigation hoàn tất"""
        await self.page.wait_for_load_state("networkidle", timeout=timeout)
    
    async def wait_and_click(
        self, 
        selector: str, 
        timeout: int = 10000,
        force: bool = False
    ) -> bool:
        """
        Helper: Đợi element xuất hiện và click.
        
        Returns:
            True nếu click thành công, False nếu không tìm thấy element
        """
        try:
            locator = self.page.locator(selector)
            await locator.wait_for(state="visible", timeout=timeout)
            await locator.click(force=force, timeout=timeout)
            return True
        except Exception as e:
            self.log_warn(f"Failed to click {selector}: {e}")
            return False
    
    async def wait_and_fill(
        self,
        selector: str,
        value: str,
        timeout: int = 10000
    ) -> bool:
        """
        Helper: Đợi input field và điền giá trị.
        
        Returns:
            True nếu fill thành công
        """
        try:
            locator = self.page.locator(selector)
            await locator.wait_for(state="visible", timeout=timeout)
            await locator.fill(value, timeout=timeout)
            return True
        except Exception as e:
            self.log_warn(f"Failed to fill {selector}: {e}")
            return False
    
    async def try_click_selectors(
        self,
        selectors: list[str],
        timeout: int = 5000
    ) -> Optional[str]:
        """
        Thử click lần lượt các selectors cho đến khi thành công.
        
        Args:
            selectors: Danh sách CSS selectors để thử
            timeout: Timeout cho mỗi selector
            
        Returns:
            Selector đã click thành công, hoặc None nếu tất cả fail
        """
        for selector in selectors:
            try:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    await locator.first.click(timeout=timeout)
                    self.log_debug(f"Clicked selector: {selector}")
                    return selector
            except Exception:
                continue
        
        return None
    
    async def screenshot(self, name: str = "screenshot") -> Optional[str]:
        """
        Chụp screenshot để debug.
        
        Returns:
            Path đến file screenshot
        """
        try:
            import os
            from pathlib import Path
            
            screenshots_dir = Path.home() / ".veo-runner" / "screenshots"
            screenshots_dir.mkdir(parents=True, exist_ok=True)
            
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{name}_{timestamp}.png"
            filepath = screenshots_dir / filename
            
            await self.page.screenshot(path=str(filepath))
            self.log_debug(f"Screenshot saved: {filepath}")
            
            return str(filepath)
        except Exception as e:
            self.log_warn(f"Failed to take screenshot: {e}")
            return None
