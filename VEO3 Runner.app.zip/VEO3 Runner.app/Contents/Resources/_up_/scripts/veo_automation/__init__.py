"""
VEO Automation Package - Browser automation for VEO3/Google Flow

Cung cấp các action classes để thao tác trực tiếp trên browser:
- LoginAction: Đăng nhập Google OAuth
- CreateProjectAction: Tạo project mới trên VEO3
- SubmitPromptAction: Submit prompt tạo video
- ExtendVideoAction: Extend video hiện có
- DownloadVideoAction: Tải video về local
"""

from .browser import BrowserManager
from .base import BaseAction, ActionResult
from .types import (
    ProjectConfig,
    PromptConfig,
    ExtendConfig,
    VideoStatus,
    SessionStatus,
)

from .actions import (
    LoginAction,
    CreateProjectAction,
    GoToProjectAction,
    SubmitPromptAction,
    ExtendVideoAction,
    DownloadVideoAction,
    CheckStatusAction,
)

__all__ = [
    # Core
    "BrowserManager",
    "BaseAction",
    "ActionResult",
    # Types
    "ProjectConfig",
    "PromptConfig",
    "ExtendConfig",
    "VideoStatus",
    "SessionStatus",
    # Actions
    "LoginAction",
    "CreateProjectAction",
    "GoToProjectAction",
    "SubmitPromptAction",
    "ExtendVideoAction",
    "DownloadVideoAction",
    "CheckStatusAction",
]

__version__ = "0.1.0"
