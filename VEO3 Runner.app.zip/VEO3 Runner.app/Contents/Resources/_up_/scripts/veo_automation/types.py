"""
Type definitions cho VEO Automation

Sử dụng dataclasses để định nghĩa các cấu trúc dữ liệu
tương ứng với TypeScript types bên frontend.
"""

from dataclasses import dataclass, field
from typing import Optional, List, Literal
from enum import Enum


class AspectRatio(str, Enum):
    """Tỷ lệ khung hình video"""
    LANDSCAPE = "16:9"
    PORTRAIT = "9:16"
    SQUARE = "1:1"
    STANDARD = "4:3"


class VideoStyle(str, Enum):
    """Phong cách video"""
    CINEMATIC = "cinematic"
    ANIME = "anime"
    REALISTIC = "realistic"
    CARTOON = "cartoon"
    ARTISTIC = "artistic"


class VideoStatus(str, Enum):
    """Trạng thái video generation"""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class SessionStatus:
    """Trạng thái browser session"""
    is_active: bool
    is_logged_in: bool
    cookies_valid: bool
    last_activity: Optional[str] = None
    error: Optional[str] = None


@dataclass
class ProjectConfig:
    """Cấu hình tạo project mới trên VEO3"""
    name: str
    aspect_ratio: AspectRatio = AspectRatio.LANDSCAPE
    style: VideoStyle = VideoStyle.CINEMATIC
    description: Optional[str] = None


@dataclass
class PromptConfig:
    """Cấu hình submit prompt"""
    prompt: str
    aspect_ratio: AspectRatio = AspectRatio.LANDSCAPE
    style: VideoStyle = VideoStyle.CINEMATIC
    duration: int = 8  # seconds
    seed: Optional[int] = None
    negative_prompt: Optional[str] = None


@dataclass
class ExtendConfig:
    """Cấu hình extend video"""
    video_id: str
    extend_prompt: str
    direction: Literal["forward", "backward"] = "forward"
    duration: int = 4  # seconds to extend


@dataclass
class DownloadConfig:
    """Cấu hình download video"""
    video_id: str
    output_path: str
    quality: Literal["high", "medium", "low"] = "high"


@dataclass
class VideoResult:
    """Kết quả video generation"""
    video_id: str
    status: VideoStatus
    progress: int = 0  # 0-100
    video_url: Optional[str] = None
    thumbnail_url: Optional[str] = None
    duration: Optional[float] = None
    error: Optional[str] = None
    metadata: dict = field(default_factory=dict)


@dataclass
class LoginResult:
    """Kết quả đăng nhập"""
    success: bool
    user_email: Optional[str] = None
    cookies_saved: bool = False
    error: Optional[str] = None


@dataclass
class ProjectResult:
    """Kết quả tạo/mở project"""
    success: bool
    project_id: Optional[str] = None
    project_url: Optional[str] = None
    error: Optional[str] = None
