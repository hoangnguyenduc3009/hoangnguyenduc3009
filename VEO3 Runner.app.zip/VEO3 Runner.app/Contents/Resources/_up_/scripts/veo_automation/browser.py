"""
Browser Manager - Quản lý browser instance cho VEO automation

Sử dụng Playwright để điều khiển browser, hỗ trợ:
- Khởi tạo browser với profile persist
- Quản lý context và page
- Inject cookies từ session đã lưu
"""

import asyncio
import json
from typing import Optional, Dict, Any
from pathlib import Path
from playwright.async_api import async_playwright, Browser, BrowserContext, Page, Playwright


class BrowserManager:
    """
    Quản lý Playwright browser instance.
    
    Hỗ trợ persist session qua user data directory,
    cho phép reuse login state giữa các lần chạy.
    """
    
    def __init__(
        self,
        headless: bool = False,
        data_dir: Optional[Path] = None,
        cookies_file: Optional[Path] = None,
        slow_mo: int = 0
    ):
        """
        Khởi tạo BrowserManager.
        
        Args:
            headless: Chạy browser ở chế độ headless
            data_dir: Đường dẫn lưu profile browser (persist cookies/session)
            cookies_file: File JSON chứa cookies để restore
            slow_mo: Delay giữa các action (ms) - hữu ích cho debug
        """
        self.headless = headless
        self.data_dir = data_dir
        self.cookies_file = cookies_file
        self.slow_mo = slow_mo
        
        # Playwright instances
        self._playwright: Optional[Playwright] = None
        self._browser: Optional[Browser] = None
        self._context: Optional[BrowserContext] = None
        self._page: Optional[Page] = None
    
    @property
    def page(self) -> Page:
        """Trả về page hiện tại, raise nếu chưa khởi tạo"""
        if self._page is None:
            raise RuntimeError("Browser chưa được khởi tạo. Gọi start() trước.")
        return self._page
    
    @property
    def context(self) -> BrowserContext:
        """Trả về browser context hiện tại"""
        if self._context is None:
            raise RuntimeError("Browser chưa được khởi tạo. Gọi start() trước.")
        return self._context
    
    @property
    def browser(self) -> Browser:
        """Trả về browser instance"""
        if self._browser is None:
            raise RuntimeError("Browser chưa được khởi tạo. Gọi start() trước.")
        return self._browser
    
    # URLs constants
    VEO3_FLOW_URL = "https://labs.google/fx/tools/video-fx"
    VEO3_HOME_URL = "https://labs.google/fx"
    GOOGLE_LOGIN_URL = "https://accounts.google.com"
    
    def get_session_status(self) -> Dict[str, Any]:
        """
        Kiểm tra trạng thái session từ cookies file.
        
        Returns:
            Dict với thông tin session status
        """
        result = {
            "has_cookies": False,
            "cookies_file": str(self.cookies_file) if self.cookies_file else None,
            "data_dir": str(self.data_dir) if self.data_dir else None,
        }
        
        if self.cookies_file and self.cookies_file.exists():
            try:
                with open(self.cookies_file, "r") as f:
                    cookies = json.load(f)
                result["has_cookies"] = len(cookies) > 0
                result["cookie_count"] = len(cookies)
                # Kiểm tra xem có Google auth cookies không
                google_cookies = [c for c in cookies if "google" in c.get("domain", "").lower()]
                result["has_google_cookies"] = len(google_cookies) > 0
            except Exception as e:
                result["error"] = str(e)
        
        return result
    
    async def start(self, restore_cookies: bool = True) -> "BrowserManager":
        """
        Khởi động browser.
        
        Nếu data_dir được cung cấp, sử dụng persistent context
        để giữ lại cookies/session giữa các lần chạy.
        
        Args:
            restore_cookies: Có restore cookies từ file không
        
        Returns:
            Self để hỗ trợ method chaining
        """
        self._playwright = await async_playwright().start()
        
        # Cấu hình browser args
        browser_args = [
            "--disable-blink-features=AutomationControlled",
            "--no-sandbox",
            "--disable-dev-shm-usage",
        ]
        
        if self.data_dir:
            # Đảm bảo data_dir tồn tại
            self.data_dir.mkdir(parents=True, exist_ok=True)
            
            # Sử dụng persistent context để lưu session
            self._context = await self._playwright.chromium.launch_persistent_context(
                user_data_dir=str(self.data_dir),
                headless=self.headless,
                slow_mo=self.slow_mo,
                args=browser_args,
                viewport={"width": 1280, "height": 800},
                locale="en-US",
                timezone_id="America/Los_Angeles",
            )
            # Persistent context có sẵn page hoặc tạo mới
            if self._context.pages:
                self._page = self._context.pages[0]
            else:
                self._page = await self._context.new_page()
        else:
            # Không persist - browser session tạm thời
            self._browser = await self._playwright.chromium.launch(
                headless=self.headless,
                slow_mo=self.slow_mo,
                args=browser_args,
            )
            self._context = await self._browser.new_context(
                viewport={"width": 1280, "height": 800},
                locale="en-US",
                timezone_id="America/Los_Angeles",
            )
            self._page = await self._context.new_page()
        
        # Restore cookies nếu có
        if restore_cookies and self.cookies_file and self.cookies_file.exists():
            await self._restore_cookies()
        
        return self
    
    async def _restore_cookies(self) -> None:
        """Restore cookies từ file"""
        try:
            with open(self.cookies_file, "r") as f:
                cookies = json.load(f)
            if cookies:
                await self._context.add_cookies(cookies)
        except Exception:
            pass  # Bỏ qua lỗi khi restore cookies
    
    async def save_cookies(self) -> None:
        """Lưu cookies hiện tại ra file"""
        if self.cookies_file and self._context:
            cookies = await self._context.cookies()
            self.cookies_file.parent.mkdir(parents=True, exist_ok=True)
            with open(self.cookies_file, "w") as f:
                json.dump(cookies, f, indent=2)
        
        return self
    
    async def check_login_status(self) -> bool:
        """
        Kiểm tra xem user đã login Google chưa.
        
        Kiểm tra bằng cách navigate đến VEO3 và check xem có bị redirect
        về trang login không.
        
        Returns:
            True nếu đã login, False nếu chưa
        """
        try:
            # Lấy URL hiện tại
            current_url = self.page.url
            
            # Nếu đang ở trang login Google -> chưa login
            if "accounts.google.com" in current_url:
                return False
            
            # Nếu đang ở trang VEO3 và có UI element của user -> đã login
            # Kiểm tra avatar hoặc user menu
            try:
                # Đợi một chút để page load
                await self.page.wait_for_timeout(500)
                
                # Tìm avatar hoặc sign in button
                signin_button = await self.page.query_selector('button:has-text("Sign in")')
                if signin_button:
                    return False
                
                # Nếu không có sign in button và đang ở trang VEO -> đã login
                if "labs.google" in current_url:
                    return True
                    
            except Exception:
                pass
            
            return False
            
        except Exception:
            return False
    
    async def navigate(
        self, 
        url: str, 
        wait_until: str = "networkidle",
        timeout: int = 30000
    ) -> bool:
        """
        Navigate đến URL với error handling.
        
        Args:
            url: URL đích
            wait_until: Điều kiện chờ (load, domcontentloaded, networkidle)
            timeout: Timeout in ms
            
        Returns:
            True nếu navigate thành công, False nếu lỗi
        """
        try:
            await self.page.goto(url, wait_until=wait_until, timeout=timeout)
            return True
        except Exception:
            return False
    
    async def get_current_url(self) -> str:
        """Trả về URL hiện tại của page"""
        return self.page.url
    
    async def wait_for_url(
        self,
        url_pattern: str,
        timeout: int = 30000
    ) -> bool:
        """
        Đợi cho đến khi URL match pattern.
        
        Args:
            url_pattern: URL hoặc regex pattern
            timeout: Timeout in ms
            
        Returns:
            True nếu URL match, False nếu timeout
        """
        try:
            await self.page.wait_for_url(url_pattern, timeout=timeout)
            return True
        except Exception:
            return False
    
    async def wait_for_selector(
        self,
        selector: str,
        timeout: int = 30000,
        state: str = "visible"
    ) -> bool:
        """
        Đợi element xuất hiện.
        
        Args:
            selector: CSS selector
            timeout: Timeout in ms
            state: visible, hidden, attached, detached
            
        Returns:
            True nếu element xuất hiện, False nếu timeout
        """
        try:
            await self.page.wait_for_selector(selector, timeout=timeout, state=state)
            return True
        except Exception:
            return False
    
    async def click(self, selector: str, timeout: int = 30000) -> bool:
        """
        Click element.
        
        Args:
            selector: CSS selector
            timeout: Timeout in ms
            
        Returns:
            True nếu click thành công, False nếu lỗi
        """
        try:
            await self.page.click(selector, timeout=timeout)
            return True
        except Exception:
            return False
    
    async def fill(self, selector: str, value: str, timeout: int = 30000) -> bool:
        """
        Điền text vào input field.
        
        Args:
            selector: CSS selector
            value: Text để điền
            timeout: Timeout in ms
            
        Returns:
            True nếu thành công, False nếu lỗi
        """
        try:
            await self.page.fill(selector, value, timeout=timeout)
            return True
        except Exception:
            return False
    
    async def get_text(self, selector: str) -> Optional[str]:
        """
        Lấy text content của element.
        
        Args:
            selector: CSS selector
            
        Returns:
            Text content hoặc None nếu không tìm thấy
        """
        try:
            element = await self.page.query_selector(selector)
            if element:
                return await element.text_content()
            return None
        except Exception:
            return None
    
    async def stop(self, save_cookies: bool = False) -> None:
        """
        Đóng browser và giải phóng resources.
        
        Args:
            save_cookies: Có lưu cookies ra file trước khi đóng không
        """
        # Lưu cookies nếu được yêu cầu
        if save_cookies:
            await self.save_cookies()
        
        if self._context:
            await self._context.close()
            self._context = None
            self._page = None
        
        if self._browser:
            await self._browser.close()
            self._browser = None
        
        if self._playwright:
            await self._playwright.stop()
            self._playwright = None
    
    async def new_page(self) -> Page:
        """Tạo page mới trong context hiện tại"""
        if self._context is None:
            raise RuntimeError("Browser chưa được khởi tạo. Gọi start() trước.")
        return await self._context.new_page()
    
    async def goto(self, url: str, wait_until: str = "networkidle") -> None:
        """
        Navigate đến URL.
        
        Args:
            url: URL đích
            wait_until: Điều kiện chờ (load, domcontentloaded, networkidle)
        """
        await self.page.goto(url, wait_until=wait_until)
    
    async def screenshot(self, path: str) -> None:
        """Chụp screenshot page hiện tại"""
        await self.page.screenshot(path=path)
    
    async def get_cookies(self) -> list:
        """Lấy tất cả cookies từ context"""
        return await self.context.cookies()
    
    async def set_cookies(self, cookies: list) -> None:
        """Set cookies vào context"""
        await self.context.add_cookies(cookies)
    
    async def clear_cookies(self) -> None:
        """Xóa tất cả cookies"""
        await self.context.clear_cookies()
    
    async def __aenter__(self) -> "BrowserManager":
        """Async context manager entry"""
        await self.start()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Async context manager exit"""
        await self.stop()
