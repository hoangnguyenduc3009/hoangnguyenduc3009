"""
Submit Prompt Action - Submit prompt để generate video trên VEO3

Flow:
1. Navigate đến project (nếu chưa ở đó)
2. Điền prompt vào textarea
3. Chọn các options (duration, aspect ratio, style)
4. Click Generate
5. Đợi và trả về job ID/status
"""

import asyncio
from typing import Optional

from ..base import BaseAction, ActionResult
from ..browser import BrowserManager
from ..utils.selectors import Selectors
from ..types import PromptConfig, VideoResult, VideoStatus


class SubmitPromptAction(BaseAction):
    """
    Action submit prompt để generate video.
    
    Điền prompt vào VEO3 interface và trigger generation.
    """
    
    ACTION_NAME = "submit_prompt"
    
    async def execute(
        self,
        prompt: str,
        aspect_ratio: str = "16:9",
        style: str = "cinematic",
        duration: int = 8,
        seed: Optional[int] = None,
        negative_prompt: Optional[str] = None,
        project_id: Optional[str] = None,
        **kwargs
    ) -> ActionResult:
        """
        Submit prompt để generate video.
        
        Args:
            prompt: Mô tả video cần tạo
            aspect_ratio: Tỷ lệ khung hình
            style: Phong cách video
            duration: Thời lượng video (seconds)
            seed: Random seed (optional)
            negative_prompt: Những gì không muốn trong video (optional)
            project_id: ID project để submit vào (optional)
            
        Returns:
            ActionResult với video_id và status
        """
        try:
            self.log_info(f"Submitting prompt: {prompt[:50]}...")
            
            # Step 1: Navigate đến project nếu cần
            if project_id:
                await self._navigate_to_project(project_id)
            
            # Step 2: Đợi page ready
            await self._wait_for_prompt_ready()
            
            # Step 3: Điền prompt
            filled = await self._fill_prompt(prompt)
            
            if not filled:
                return ActionResult.error_result(
                    action=self.ACTION_NAME,
                    error="Could not find or fill prompt input"
                )
            
            # Step 4: Set các options
            await self._set_duration(duration)
            
            if seed is not None:
                await self._set_seed(seed)
            
            if negative_prompt:
                await self._set_negative_prompt(negative_prompt)
            
            # Step 5: Click Generate
            generated = await self._click_generate()
            
            if not generated:
                return ActionResult.error_result(
                    action=self.ACTION_NAME,
                    error="Failed to click generate button"
                )
            
            # Step 6: Đợi response và lấy video ID
            await asyncio.sleep(3)  # Đợi request được gửi
            
            video_id = await self._get_video_id()
            current_url = await self.browser.get_current_url()
            
            self.log_info(f"Prompt submitted successfully, video_id: {video_id}")
            
            return ActionResult.success_result(
                action=self.ACTION_NAME,
                data={
                    "success": True,
                    "video_id": video_id,
                    "status": VideoStatus.PENDING.value,
                    "prompt": prompt,
                    "aspect_ratio": aspect_ratio,
                    "style": style,
                    "duration": duration,
                    "url": current_url,
                }
            )
            
        except Exception as e:
            self.log_error(f"Failed to submit prompt: {str(e)}")
            await self.screenshot("submit_prompt_error")
            return ActionResult.error_result(
                action=self.ACTION_NAME,
                error=str(e)
            )
    
    async def _navigate_to_project(self, project_id: str) -> bool:
        """Navigate đến project cụ thể"""
        url = f"{self.browser.VEO3_FLOW_URL}/project/{project_id}"
        return await self.browser.navigate(url, timeout=30000)
    
    async def _wait_for_prompt_ready(self, timeout: int = 10000) -> bool:
        """Đợi prompt textarea xuất hiện và ready"""
        for selector in Selectors.Prompt.PROMPT_INPUT:
            try:
                locator = self.page.locator(selector)
                await locator.wait_for(state="visible", timeout=timeout)
                return True
            except Exception:
                continue
        return False
    
    async def _fill_prompt(self, prompt: str) -> bool:
        """Điền prompt vào textarea"""
        for selector in Selectors.Prompt.PROMPT_INPUT:
            try:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    # Clear existing content
                    await locator.clear()
                    # Fill new prompt
                    await locator.fill(prompt)
                    self.log_debug("Prompt filled successfully")
                    return True
            except Exception as e:
                self.log_debug(f"Failed with selector {selector}: {e}")
                continue
        
        # Fallback: thử type thay vì fill
        try:
            await self.page.keyboard.type(prompt)
            return True
        except Exception:
            pass
        
        return False
    
    async def _set_duration(self, duration: int) -> bool:
        """Set video duration"""
        # Thử slider trước
        try:
            for selector in Selectors.Prompt.DURATION_SLIDER:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    # Set value trực tiếp qua JavaScript
                    await locator.evaluate(f"el => el.value = {duration}")
                    await locator.dispatch_event("change")
                    self.log_debug(f"Set duration: {duration}s")
                    return True
        except Exception:
            pass
        
        # Thử input number
        try:
            for selector in Selectors.Prompt.DURATION_INPUT:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    await locator.fill(str(duration))
                    self.log_debug(f"Set duration: {duration}s")
                    return True
        except Exception:
            pass
        
        return False
    
    async def _set_seed(self, seed: int) -> bool:
        """Set random seed"""
        for selector in Selectors.Prompt.SEED_INPUT:
            try:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    await locator.fill(str(seed))
                    self.log_debug(f"Set seed: {seed}")
                    return True
            except Exception:
                continue
        return False
    
    async def _set_negative_prompt(self, negative_prompt: str) -> bool:
        """Set negative prompt"""
        # Toggle negative prompt section
        clicked = await self.try_click_selectors(
            Selectors.Prompt.NEGATIVE_PROMPT_TOGGLE,
            timeout=3000
        )
        
        if not clicked:
            self.log_debug("Negative prompt toggle not found")
            return False
        
        await asyncio.sleep(0.5)
        
        # Fill negative prompt
        for selector in Selectors.Prompt.NEGATIVE_PROMPT_INPUT:
            try:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    await locator.fill(negative_prompt)
                    self.log_debug("Set negative prompt")
                    return True
            except Exception:
                continue
        
        return False
    
    async def _click_generate(self) -> bool:
        """Click nút Generate"""
        clicked = await self.try_click_selectors(
            Selectors.Prompt.GENERATE_BUTTON,
            timeout=10000
        )
        
        if clicked:
            self.log_info("Clicked Generate button")
            return True
        
        self.log_warn("Generate button not found")
        return False
    
    async def _get_video_id(self) -> str:
        """Lấy video ID sau khi submit"""
        # Thử lấy từ URL
        current_url = await self.browser.get_current_url()
        
        import re
        
        # Pattern: /video/abc123 hoặc /generation/abc123
        patterns = [
            r'/video/([a-zA-Z0-9_-]+)',
            r'/generation/([a-zA-Z0-9_-]+)',
            r'video_id=([a-zA-Z0-9_-]+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, current_url)
            if match:
                return match.group(1)
        
        # Fallback: generate unique ID
        from datetime import datetime
        return f"video_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
