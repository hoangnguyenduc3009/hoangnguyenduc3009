"""
Download Video Action - Download video từ VEO3 về local

Flow:
1. Navigate đến video
2. Đợi video ready (status = completed)
3. Click nút Download
4. Intercept download và save về đường dẫn chỉ định
"""

import asyncio
import os
from pathlib import Path
from typing import Optional

from ..base import BaseAction, ActionResult
from ..browser import BrowserManager
from ..utils.selectors import Selectors


class DownloadVideoAction(BaseAction):
    """
    Action download video đã generate về local.
    
    Hỗ trợ:
    - Download từ URL trực tiếp
    - Download từ video ID
    - Custom output path
    """
    
    ACTION_NAME = "download_video"
    
    # Default download directory
    DEFAULT_DOWNLOAD_DIR = Path.home() / ".veo-runner" / "downloads"
    
    async def execute(
        self,
        video_id: str,
        output_path: Optional[str] = None,
        video_url: Optional[str] = None,
        quality: str = "high",
        timeout: int = 60000,
        **kwargs
    ) -> ActionResult:
        """
        Download video về local.
        
        Args:
            video_id: ID của video cần download
            output_path: Đường dẫn file output (optional, auto-generate nếu không có)
            video_url: URL trực tiếp đến video page (optional)
            quality: Chất lượng video (high, medium, low)
            timeout: Timeout cho download (ms)
            
        Returns:
            ActionResult với local_path và file info
        """
        try:
            self.log_info(f"Downloading video: {video_id}")
            
            # Step 1: Prepare output path
            if output_path:
                output_file = Path(output_path)
            else:
                output_file = self._generate_output_path(video_id)
            
            # Ensure directory exists
            output_file.parent.mkdir(parents=True, exist_ok=True)
            
            # Step 2: Navigate đến video page
            if video_url:
                success = await self.browser.navigate(video_url, timeout=30000)
            else:
                url = f"{self.browser.VEO3_FLOW_URL}/video/{video_id}"
                success = await self.browser.navigate(url, timeout=30000)
            
            if not success:
                return ActionResult.error_result(
                    action=self.ACTION_NAME,
                    error=f"Failed to navigate to video: {video_id}"
                )
            
            await asyncio.sleep(2)
            
            # Step 3: Check video status
            is_ready = await self._check_video_ready()
            
            if not is_ready:
                return ActionResult.error_result(
                    action=self.ACTION_NAME,
                    error="Video is not ready for download. Please wait for processing to complete."
                )
            
            # Step 4: Get video source URL và download
            video_src = await self._get_video_source()
            
            if video_src:
                # Download trực tiếp từ source URL
                downloaded = await self._download_from_url(video_src, output_file, timeout)
            else:
                # Fallback: Click download button
                downloaded = await self._click_download_button(output_file, timeout)
            
            if not downloaded:
                return ActionResult.error_result(
                    action=self.ACTION_NAME,
                    error="Failed to download video"
                )
            
            # Step 5: Verify download
            if output_file.exists():
                file_size = output_file.stat().st_size
                self.log_info(f"Video downloaded: {output_file} ({file_size} bytes)")
                
                return ActionResult.success_result(
                    action=self.ACTION_NAME,
                    data={
                        "success": True,
                        "video_id": video_id,
                        "local_path": str(output_file),
                        "file_size": file_size,
                        "quality": quality,
                    }
                )
            else:
                return ActionResult.error_result(
                    action=self.ACTION_NAME,
                    error="Download completed but file not found"
                )
            
        except Exception as e:
            self.log_error(f"Failed to download video: {str(e)}")
            return ActionResult.error_result(
                action=self.ACTION_NAME,
                error=str(e)
            )
    
    def _generate_output_path(self, video_id: str) -> Path:
        """Generate output path từ video ID"""
        from datetime import datetime
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{video_id}_{timestamp}.mp4"
        
        return self.DEFAULT_DOWNLOAD_DIR / filename
    
    async def _check_video_ready(self) -> bool:
        """Check nếu video đã ready để download"""
        # Check xem có download button không
        for selector in Selectors.Video.DOWNLOAD_BUTTON:
            try:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    return True
            except Exception:
                continue
        
        # Check status indicators
        for selector in Selectors.Video.STATUS_COMPLETED:
            try:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    return True
            except Exception:
                continue
        
        # Check nếu có video element với src
        try:
            video = self.page.locator("video")
            if await video.count() > 0:
                src = await video.get_attribute("src")
                if src and src.startswith("http"):
                    return True
        except Exception:
            pass
        
        return False
    
    async def _get_video_source(self) -> Optional[str]:
        """Lấy video source URL từ video element"""
        try:
            # Thử lấy từ video element
            video = self.page.locator("video")
            if await video.count() > 0:
                src = await video.get_attribute("src")
                if src and src.startswith("http"):
                    return src
            
            # Thử lấy từ source element
            source = self.page.locator("video source")
            if await source.count() > 0:
                src = await source.get_attribute("src")
                if src and src.startswith("http"):
                    return src
            
        except Exception as e:
            self.log_debug(f"Could not get video source: {e}")
        
        return None
    
    async def _download_from_url(
        self,
        url: str,
        output_path: Path,
        timeout: int
    ) -> bool:
        """Download video từ URL trực tiếp"""
        self.log_info(f"Downloading from: {url}")
        
        try:
            # Sử dụng Playwright để download
            async with self.page.context.new_page() as download_page:
                response = await download_page.goto(url, timeout=timeout)
                
                if response and response.ok:
                    # Lấy body bytes
                    body = await response.body()
                    
                    # Write to file
                    with open(output_path, "wb") as f:
                        f.write(body)
                    
                    return True
                    
        except Exception as e:
            self.log_warn(f"Direct download failed: {e}")
        
        return False
    
    async def _click_download_button(
        self,
        output_path: Path,
        timeout: int
    ) -> bool:
        """Click download button và handle download"""
        try:
            # Setup download handler
            async with self.page.expect_download(timeout=timeout) as download_info:
                # Click download button
                clicked = await self.try_click_selectors(
                    Selectors.Video.DOWNLOAD_BUTTON,
                    timeout=10000
                )
                
                if not clicked:
                    self.log_warn("Download button not found")
                    return False
            
            # Wait for download to complete
            download = await download_info.value
            
            # Save to specified path
            await download.save_as(str(output_path))
            
            self.log_info(f"Download saved to: {output_path}")
            return True
            
        except Exception as e:
            self.log_error(f"Download via button failed: {e}")
            return False
