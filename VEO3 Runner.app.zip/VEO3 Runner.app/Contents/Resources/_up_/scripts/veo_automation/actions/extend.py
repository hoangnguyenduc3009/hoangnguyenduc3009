"""
Extend Video Action - Extend video hiện có trên VEO3

Flow:
1. Navigate đến video cần extend
2. Click nút Extend
3. Chọn direction (forward/backward)
4. Điền extend prompt (optional)
5. Confirm extend
6. Đợi và trả về job ID/status
"""

import asyncio
from typing import Optional, Literal

from ..base import BaseAction, ActionResult
from ..browser import BrowserManager
from ..utils.selectors import Selectors
from ..types import ExtendConfig, VideoResult, VideoStatus


class ExtendVideoAction(BaseAction):
    """
    Action extend video đã generate.
    
    Cho phép kéo dài video về trước (backward) hoặc sau (forward).
    """
    
    ACTION_NAME = "extend_video"
    
    async def execute(
        self,
        video_id: str,
        extend_prompt: Optional[str] = None,
        direction: Literal["forward", "backward"] = "forward",
        duration: int = 4,
        video_url: Optional[str] = None,
        **kwargs
    ) -> ActionResult:
        """
        Extend video hiện có.
        
        Args:
            video_id: ID của video cần extend
            extend_prompt: Mô tả phần extend (optional, để trống sẽ tự generate)
            direction: Hướng extend - "forward" (thêm sau) hoặc "backward" (thêm trước)
            duration: Thời lượng phần extend (seconds)
            video_url: URL trực tiếp đến video (optional)
            
        Returns:
            ActionResult với new_video_id và status
        """
        try:
            self.log_info(f"Extending video {video_id} ({direction})...")
            
            # Step 1: Navigate đến video
            if video_url:
                success = await self.browser.navigate(video_url, timeout=30000)
            else:
                # Build URL từ video_id
                url = f"{self.browser.VEO3_FLOW_URL}/video/{video_id}"
                success = await self.browser.navigate(url, timeout=30000)
            
            if not success:
                return ActionResult.error_result(
                    action=self.ACTION_NAME,
                    error=f"Failed to navigate to video: {video_id}"
                )
            
            await asyncio.sleep(2)
            
            # Step 2: Click nút Extend
            clicked = await self._click_extend_button()
            
            if not clicked:
                return ActionResult.error_result(
                    action=self.ACTION_NAME,
                    error="Extend button not found. Video may still be processing."
                )
            
            await asyncio.sleep(1)
            
            # Step 3: Chọn direction
            await self._select_direction(direction)
            
            # Step 4: Điền extend prompt nếu có
            if extend_prompt:
                await self._fill_extend_prompt(extend_prompt)
            
            # Step 5: Confirm extend
            confirmed = await self._confirm_extend()
            
            if not confirmed:
                return ActionResult.error_result(
                    action=self.ACTION_NAME,
                    error="Failed to confirm extend action"
                )
            
            # Step 6: Đợi và lấy new video ID
            await asyncio.sleep(3)
            
            new_video_id = await self._get_new_video_id()
            current_url = await self.browser.get_current_url()
            
            self.log_info(f"Video extend initiated, new_video_id: {new_video_id}")
            
            return ActionResult.success_result(
                action=self.ACTION_NAME,
                data={
                    "success": True,
                    "original_video_id": video_id,
                    "new_video_id": new_video_id,
                    "status": VideoStatus.PENDING.value,
                    "direction": direction,
                    "extend_prompt": extend_prompt,
                    "duration": duration,
                    "url": current_url,
                }
            )
            
        except Exception as e:
            self.log_error(f"Failed to extend video: {str(e)}")
            await self.screenshot("extend_video_error")
            return ActionResult.error_result(
                action=self.ACTION_NAME,
                error=str(e)
            )
    
    async def _click_extend_button(self) -> bool:
        """Click nút Extend trên video player"""
        clicked = await self.try_click_selectors(
            Selectors.Video.EXTEND_BUTTON,
            timeout=10000
        )
        
        if clicked:
            self.log_debug("Clicked Extend button")
            return True
        
        return False
    
    async def _select_direction(self, direction: str) -> bool:
        """Chọn hướng extend (forward/backward)"""
        if direction == "forward":
            selectors = Selectors.Extend.EXTEND_FORWARD
        else:
            selectors = Selectors.Extend.EXTEND_BACKWARD
        
        clicked = await self.try_click_selectors(selectors, timeout=5000)
        
        if clicked:
            self.log_debug(f"Selected direction: {direction}")
            return True
        
        # Nếu không tìm thấy buttons, có thể direction đã được set sẵn
        self.log_debug(f"Direction selector not found, using default")
        return False
    
    async def _fill_extend_prompt(self, prompt: str) -> bool:
        """Điền prompt cho phần extend"""
        for selector in Selectors.Extend.EXTEND_PROMPT_INPUT:
            try:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    await locator.fill(prompt)
                    self.log_debug("Extend prompt filled")
                    return True
            except Exception:
                continue
        
        self.log_debug("Extend prompt input not found")
        return False
    
    async def _confirm_extend(self) -> bool:
        """Confirm extend action"""
        # Thử click nút "Extend video" cụ thể
        clicked = await self.try_click_selectors(
            Selectors.Extend.CONFIRM_EXTEND,
            timeout=5000
        )
        
        if clicked:
            self.log_debug("Confirmed extend")
            return True
        
        # Fallback: thử click nút Confirm chung
        clicked = await self.try_click_selectors(
            Selectors.Common.CONFIRM_BUTTON,
            timeout=5000
        )
        
        if clicked:
            self.log_debug("Confirmed extend (fallback)")
            return True
        
        return False
    
    async def _get_new_video_id(self) -> str:
        """Lấy video ID mới sau khi extend"""
        current_url = await self.browser.get_current_url()
        
        import re
        
        patterns = [
            r'/video/([a-zA-Z0-9_-]+)',
            r'/generation/([a-zA-Z0-9_-]+)',
            r'video_id=([a-zA-Z0-9_-]+)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, current_url)
            if match:
                return match.group(1)
        
        # Fallback
        from datetime import datetime
        return f"extended_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
