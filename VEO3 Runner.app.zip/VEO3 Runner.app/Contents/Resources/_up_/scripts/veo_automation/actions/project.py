"""
Project Actions - Tạo và quản lý projects trên VEO3

Actions:
- CreateProjectAction: Tạo project mới
- GoToProjectAction: Navigate đến project có sẵn
"""

import asyncio
from typing import Optional, Dict, Any

from ..base import BaseAction, ActionResult
from ..browser import BrowserManager
from ..utils.selectors import Selectors
from ..types import ProjectConfig, ProjectResult, AspectRatio, VideoStyle


class CreateProjectAction(BaseAction):
    """
    Action tạo project mới trên VEO3.
    
    Flow:
    1. Navigate đến VEO3 Flow page
    2. Click "New project" hoặc "Create project"
    3. Điền thông tin project (name, aspect ratio, style)
    4. Confirm tạo project
    5. Trả về project URL/ID
    """
    
    ACTION_NAME = "create_project"
    
    async def execute(
        self,
        name: str = "Untitled Project",
        aspect_ratio: str = "16:9",
        style: str = "cinematic",
        description: Optional[str] = None,
        **kwargs
    ) -> ActionResult:
        """
        Tạo project mới.
        
        Args:
            name: Tên project
            aspect_ratio: Tỷ lệ khung hình (16:9, 9:16, 1:1, 4:3)
            style: Phong cách video (cinematic, anime, realistic, etc.)
            description: Mô tả project (optional)
            
        Returns:
            ActionResult với project_id và project_url
        """
        try:
            self.log_info(f"Creating new project: {name}")
            
            # Step 1: Navigate đến Flow page nếu chưa ở đó
            current_url = await self.browser.get_current_url()
            
            if "labs.google" not in current_url:
                self.log_info("Navigating to VEO3 Flow...")
                success = await self.browser.navigate(
                    self.browser.VEO3_FLOW_URL,
                    timeout=30000
                )
                
                if not success:
                    return ActionResult.error_result(
                        action=self.ACTION_NAME,
                        error="Failed to navigate to VEO3"
                    )
            
            await asyncio.sleep(2)
            
            # Step 2: Click nút tạo project
            clicked = await self.try_click_selectors(
                Selectors.Project.CREATE_PROJECT,
                timeout=10000
            )
            
            if not clicked:
                self.log_warn("Create project button not found, trying alternative approach")
                # Có thể đã ở trang tạo project rồi, hoặc cần click khác
            
            await asyncio.sleep(1)
            
            # Step 3: Điền tên project
            filled = await self._fill_project_name(name)
            
            if not filled:
                self.log_warn("Could not fill project name, continuing...")
            
            # Step 4: Chọn aspect ratio
            await self._select_aspect_ratio(aspect_ratio)
            
            # Step 5: Chọn style
            await self._select_style(style)
            
            # Step 6: Confirm tạo
            await self._confirm_create()
            
            # Step 7: Đợi project được tạo và lấy URL/ID
            await asyncio.sleep(2)
            project_url = await self.browser.get_current_url()
            project_id = self._extract_project_id(project_url)
            
            self.log_info(f"Project created: {project_id}")
            
            return ActionResult.success_result(
                action=self.ACTION_NAME,
                data={
                    "success": True,
                    "project_id": project_id,
                    "project_url": project_url,
                    "name": name,
                    "aspect_ratio": aspect_ratio,
                    "style": style,
                }
            )
            
        except Exception as e:
            self.log_error(f"Failed to create project: {str(e)}")
            return ActionResult.error_result(
                action=self.ACTION_NAME,
                error=str(e)
            )
    
    async def _fill_project_name(self, name: str) -> bool:
        """Điền tên project vào input field"""
        for selector in Selectors.Project.PROJECT_NAME_INPUT:
            try:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    await locator.fill(name)
                    self.log_debug(f"Filled project name: {name}")
                    return True
            except Exception:
                continue
        return False
    
    async def _select_aspect_ratio(self, aspect_ratio: str) -> bool:
        """Chọn aspect ratio từ dropdown"""
        # Click dropdown
        clicked = await self.try_click_selectors(
            Selectors.Project.ASPECT_RATIO_DROPDOWN,
            timeout=5000
        )
        
        if not clicked:
            self.log_debug("Aspect ratio dropdown not found")
            return False
        
        await asyncio.sleep(0.5)
        
        # Chọn option tương ứng
        ratio_selectors = {
            "16:9": Selectors.Project.ASPECT_RATIO_16_9,
            "9:16": Selectors.Project.ASPECT_RATIO_9_16,
            "1:1": Selectors.Project.ASPECT_RATIO_1_1,
        }
        
        selectors = ratio_selectors.get(aspect_ratio, ratio_selectors["16:9"])
        clicked = await self.try_click_selectors(selectors, timeout=3000)
        
        if clicked:
            self.log_debug(f"Selected aspect ratio: {aspect_ratio}")
            return True
        
        return False
    
    async def _select_style(self, style: str) -> bool:
        """Chọn video style từ dropdown"""
        # Click dropdown
        clicked = await self.try_click_selectors(
            Selectors.Project.STYLE_DROPDOWN,
            timeout=5000
        )
        
        if not clicked:
            self.log_debug("Style dropdown not found")
            return False
        
        await asyncio.sleep(0.5)
        
        # Click option có text match
        try:
            option = self.page.locator(f"li:has-text('{style}')").first
            if await option.count() > 0:
                await option.click()
                self.log_debug(f"Selected style: {style}")
                return True
        except Exception:
            pass
        
        return False
    
    async def _confirm_create(self) -> bool:
        """Click nút confirm tạo project"""
        clicked = await self.try_click_selectors(
            Selectors.Common.CONFIRM_BUTTON,
            timeout=5000
        )
        
        if clicked:
            self.log_debug("Confirmed project creation")
        
        return clicked is not None
    
    def _extract_project_id(self, url: str) -> str:
        """Extract project ID từ URL"""
        # URL format: https://labs.google/fx/tools/flow/project/abc123
        import re
        match = re.search(r'/project/([a-zA-Z0-9_-]+)', url)
        if match:
            return match.group(1)
        
        # Fallback: dùng timestamp
        from datetime import datetime
        return f"project_{datetime.now().strftime('%Y%m%d_%H%M%S')}"


class GoToProjectAction(BaseAction):
    """
    Action navigate đến project có sẵn.
    
    Có thể navigate bằng:
    - Project URL trực tiếp
    - Project ID
    - Tìm trong list projects
    """
    
    ACTION_NAME = "goto_project"
    
    async def execute(
        self,
        project_id: Optional[str] = None,
        project_url: Optional[str] = None,
        project_name: Optional[str] = None,
        **kwargs
    ) -> ActionResult:
        """
        Navigate đến project.
        
        Args:
            project_id: ID của project
            project_url: URL đầy đủ của project
            project_name: Tên project để tìm trong list
            
        Returns:
            ActionResult với project info
        """
        try:
            # Ưu tiên 1: Dùng URL trực tiếp
            if project_url:
                self.log_info(f"Navigating to project URL: {project_url}")
                success = await self.browser.navigate(project_url, timeout=30000)
                
                if success:
                    return ActionResult.success_result(
                        action=self.ACTION_NAME,
                        data={
                            "success": True,
                            "project_url": project_url,
                            "project_id": project_id or self._extract_project_id(project_url),
                        }
                    )
            
            # Ưu tiên 2: Build URL từ project_id
            if project_id:
                url = f"{self.browser.VEO3_FLOW_URL}/project/{project_id}"
                self.log_info(f"Navigating to project: {project_id}")
                
                success = await self.browser.navigate(url, timeout=30000)
                
                if success:
                    return ActionResult.success_result(
                        action=self.ACTION_NAME,
                        data={
                            "success": True,
                            "project_url": url,
                            "project_id": project_id,
                        }
                    )
            
            # Ưu tiên 3: Tìm project theo tên
            if project_name:
                return await self._find_project_by_name(project_name)
            
            return ActionResult.error_result(
                action=self.ACTION_NAME,
                error="No project identifier provided (url, id, or name)"
            )
            
        except Exception as e:
            self.log_error(f"Failed to navigate to project: {str(e)}")
            return ActionResult.error_result(
                action=self.ACTION_NAME,
                error=str(e)
            )
    
    async def _find_project_by_name(self, name: str) -> ActionResult:
        """Tìm và click vào project theo tên trong list"""
        # Navigate đến project list
        await self.browser.navigate(self.browser.VEO3_FLOW_URL, timeout=30000)
        await asyncio.sleep(2)
        
        # Tìm project item có tên match
        try:
            project_item = self.page.locator(f"text={name}").first
            
            if await project_item.count() > 0:
                await project_item.click()
                await asyncio.sleep(2)
                
                project_url = await self.browser.get_current_url()
                project_id = self._extract_project_id(project_url)
                
                return ActionResult.success_result(
                    action=self.ACTION_NAME,
                    data={
                        "success": True,
                        "project_url": project_url,
                        "project_id": project_id,
                        "project_name": name,
                    }
                )
        except Exception as e:
            self.log_warn(f"Could not find project by name: {e}")
        
        return ActionResult.error_result(
            action=self.ACTION_NAME,
            error=f"Project not found: {name}"
        )
    
    def _extract_project_id(self, url: str) -> str:
        """Extract project ID từ URL"""
        import re
        match = re.search(r'/project/([a-zA-Z0-9_-]+)', url)
        if match:
            return match.group(1)
        return "unknown"
