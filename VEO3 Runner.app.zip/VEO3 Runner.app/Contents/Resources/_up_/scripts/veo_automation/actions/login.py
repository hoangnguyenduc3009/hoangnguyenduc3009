"""
Login Action - Xử lý Google OAuth login cho VEO3

Flow:
1. Navigate đến VEO3 Flow page
2. Click nút "Create with Flow" hoặc "Sign in"
3. Đợi user hoàn tất Google OAuth (manual)
4. Detect login success qua URL change hoặc cookies
5. Save cookies để restore session sau này
"""

import asyncio
from typing import Optional, Tuple

from ..base import BaseAction, ActionResult
from ..browser import BrowserManager
from ..utils.selectors import Selectors
from ..types import LoginResult


class LoginAction(BaseAction):
    """
    Action đăng nhập Google OAuth cho VEO3.
    
    User cần tự nhập credentials trên Google login page,
    action này chỉ navigate và detect khi nào login xong.
    """
    
    ACTION_NAME = "login"
    
    # Timeout chờ user login (5 phút)
    LOGIN_TIMEOUT = 300000
    
    async def execute(
        self,
        auto_click_signin: bool = True,
        wait_for_manual_login: bool = True,
        **kwargs
    ) -> ActionResult:
        """
        Thực hiện login flow.
        
        Args:
            auto_click_signin: Tự động click nút Sign in/Create with Flow
            wait_for_manual_login: Đợi user hoàn tất manual login
            
        Returns:
            ActionResult với LoginResult data
        """
        try:
            # Step 1: Check nếu đã có session valid
            self.log_info("Checking existing session...")
            
            if await self.browser.check_login_status():
                self.log_info("Already logged in with valid session")
                user_email, user_name = await self._get_user_info()
                return ActionResult.success_result(
                    action=self.ACTION_NAME,
                    data={
                        "success": True,
                        "user_email": user_email,
                        "user_name": user_name,
                        "cookies_saved": True,
                        "already_logged_in": True,
                    }
                )
            
            # Step 2: Navigate đến VEO3 Flow page
            self.log_info(f"Navigating to {self.browser.VEO3_FLOW_URL}")
            
            success = await self.browser.navigate(
                self.browser.VEO3_FLOW_URL,
                wait_until="networkidle",
                timeout=30000
            )
            
            if not success:
                return ActionResult.error_result(
                    action=self.ACTION_NAME,
                    error="Failed to navigate to VEO3 Flow page"
                )
            
            # Step 3: Click Sign in button nếu có
            if auto_click_signin:
                await self._click_signin_button()
            
            # Step 4: Đợi user hoàn tất login
            if wait_for_manual_login:
                self.log_info("Waiting for user to complete Google login...")
                self.log_info("Please log in with your Google account in the browser window")
                
                login_success = await self._wait_for_login_complete()
                
                if not login_success:
                    return ActionResult.error_result(
                        action=self.ACTION_NAME,
                        error="Login timeout or failed. Please try again."
                    )
            
            # Step 5: Verify login success
            is_logged_in = await self.browser.check_login_status()
            
            if not is_logged_in:
                return ActionResult.error_result(
                    action=self.ACTION_NAME,
                    error="Login verification failed"
                )
            
            # Step 6: Get user info - Mở account menu trước để lấy thông tin
            user_email, user_name = await self._get_user_info()
            
            display_name = user_name or user_email or 'unknown'
            self.log_info(f"Login successful! User: {display_name}")
            
            return ActionResult.success_result(
                action=self.ACTION_NAME,
                data={
                    "success": True,
                    "user_email": user_email,
                    "user_name": user_name,
                    "cookies_saved": True,
                    "already_logged_in": False,
                }
            )
            
        except Exception as e:
            self.log_error(f"Login failed: {str(e)}")
            return ActionResult.error_result(
                action=self.ACTION_NAME,
                error=str(e)
            )
    
    async def _click_signin_button(self) -> bool:
        """
        Thử click các nút Sign in / Create with Flow.
        
        Returns:
            True nếu click thành công
        """
        # Đợi page load
        await asyncio.sleep(2)
        
        # Thử click "Create with Flow" trước
        clicked = await self.try_click_selectors(
            Selectors.Login.CREATE_WITH_FLOW,
            timeout=5000
        )
        
        if clicked:
            self.log_info(f"Clicked: {clicked}")
            return True
        
        # Thử click "Sign in"
        clicked = await self.try_click_selectors(
            Selectors.Login.SIGN_IN_BUTTON,
            timeout=5000
        )
        
        if clicked:
            self.log_info(f"Clicked: {clicked}")
            return True
        
        self.log_warn("No sign-in button found, user may need to click manually")
        return False
    
    async def _wait_for_login_complete(self) -> bool:
        """
        Đợi cho đến khi user hoàn tất login.
        
        Detect bằng cách:
        1. Check URL change (không còn accounts.google.com)
        2. Check cookies xuất hiện
        3. Check user avatar xuất hiện
        
        Returns:
            True nếu login thành công
        """
        start_time = asyncio.get_event_loop().time()
        check_interval = 2  # seconds
        
        while True:
            elapsed = asyncio.get_event_loop().time() - start_time
            elapsed_ms = elapsed * 1000
            
            # Timeout check
            if elapsed_ms > self.LOGIN_TIMEOUT:
                self.log_warn("Login timeout exceeded")
                return False
            
            # Check current URL
            current_url = await self.browser.get_current_url()
            
            # Nếu đang ở Google accounts page, vẫn đang login
            if "accounts.google.com" in current_url:
                self.log_debug(f"Still on Google login page... ({int(elapsed)}s)")
                await asyncio.sleep(check_interval)
                continue
            
            # Nếu đã quay về VEO3 domain
            if "labs.google" in current_url:
                self.log_info("Detected return to VEO3 domain")
                
                # Đợi thêm để page load
                await asyncio.sleep(3)
                
                # Verify bằng session check
                if await self.browser.check_login_status():
                    return True
                
                # Hoặc check user avatar
                if await self._check_user_avatar():
                    return True
            
            await asyncio.sleep(check_interval)
            
            # Log progress mỗi 30s
            if int(elapsed) % 30 == 0 and int(elapsed) > 0:
                remaining = (self.LOGIN_TIMEOUT / 1000) - elapsed
                self.log_info(f"Waiting for login... {int(remaining)}s remaining")
    
    async def _check_user_avatar(self) -> bool:
        """Check nếu user avatar xuất hiện (đã logged in)"""
        for selector in Selectors.Login.USER_AVATAR:
            try:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    return True
            except Exception:
                continue
        return False
    
    async def _get_user_info(self) -> Tuple[Optional[str], Optional[str]]:
        """
        Lấy cả email và tên của user đã đăng nhập từ DOM.
        Mở account menu một lần và lấy cả 2 thông tin.
        
        Returns:
            Tuple (email, name) - có thể None nếu không lấy được
        """
        user_email = None
        user_name = None
        
        try:
            # Click vào account button/avatar để mở dialog chứa user info
            self.log_info("Opening account menu to get user info...")
            clicked = await self.try_click_selectors(
                Selectors.Login.ACCOUNT_MENU_BUTTON,
                timeout=5000
            )
            
            if clicked:
                self.log_debug("Clicked account menu button")
                await asyncio.sleep(1.5)  # Đợi dialog animation
            else:
                self.log_warn("Could not click account menu button")
                return (None, None)
            
            # Lấy user name từ DOM
            for selector in Selectors.Login.USER_NAME:
                try:
                    locator = self.page.locator(selector)
                    count = await locator.count()
                    self.log_debug(f"Selector '{selector}' found {count} elements")
                    if count > 0:
                        name = await locator.first.text_content()
                        if name and len(name.strip()) > 1 and "@" not in name:
                            user_name = name.strip()
                            self.log_info(f"Found user name: {user_name}")
                            break
                except Exception as e:
                    self.log_debug(f"Error with selector {selector}: {e}")
                    continue
            
            # Lấy email từ DOM
            for selector in Selectors.Login.USER_EMAIL:
                try:
                    locator = self.page.locator(selector)
                    count = await locator.count()
                    self.log_debug(f"Selector '{selector}' found {count} elements")
                    if count > 0:
                        email = await locator.first.text_content()
                        if email and "@" in email:
                            user_email = email.strip()
                            self.log_info(f"Found user email: {user_email}")
                            break
                except Exception as e:
                    self.log_debug(f"Error with selector {selector}: {e}")
                    continue
            
            # Đóng dialog bằng cách click ra ngoài hoặc nhấn Escape
            try:
                await self.page.keyboard.press("Escape")
                await asyncio.sleep(0.5)
            except Exception:
                pass
            
            return (user_email, user_name)
            
        except Exception as e:
            self.log_error(f"Error getting user info: {e}")
            return (None, None)
    
    async def _get_user_email(self) -> Optional[str]:
        """Legacy method - dùng _get_user_info() thay thế"""
        email, _ = await self._get_user_info()
        return email
    
    async def _get_user_name(self) -> Optional[str]:
        """Legacy method - dùng _get_user_info() thay thế"""
        _, name = await self._get_user_info()
        return name
