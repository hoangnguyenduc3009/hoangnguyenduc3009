"""
Check Status Action - Kiểm tra trạng thái video generation

Flow:
1. Navigate đến video page
2. Parse status từ UI hoặc API
3. Trả về status và progress
"""

import asyncio
import re
from typing import Optional

from ..base import BaseAction, ActionResult
from ..browser import BrowserManager
from ..utils.selectors import Selectors
from ..types import VideoResult, VideoStatus


class CheckStatusAction(BaseAction):
    """
    Action check trạng thái video generation.
    
    Có thể check:
    - Từ video page UI
    - Từ API endpoint (nếu có)
    """
    
    ACTION_NAME = "check_status"
    
    async def execute(
        self,
        video_id: str,
        video_url: Optional[str] = None,
        **kwargs
    ) -> ActionResult:
        """
        Check trạng thái video.
        
        Args:
            video_id: ID của video cần check
            video_url: URL trực tiếp đến video (optional)
            
        Returns:
            ActionResult với status, progress, và metadata
        """
        try:
            self.log_info(f"Checking status for video: {video_id}")
            
            # Navigate đến video page
            if video_url:
                success = await self.browser.navigate(video_url, timeout=30000)
            else:
                url = f"{self.browser.VEO3_FLOW_URL}/video/{video_id}"
                success = await self.browser.navigate(url, timeout=30000)
            
            if not success:
                return ActionResult.error_result(
                    action=self.ACTION_NAME,
                    error=f"Failed to navigate to video: {video_id}"
                )
            
            await asyncio.sleep(2)
            
            # Parse status từ page
            status = await self._parse_status()
            progress = await self._parse_progress()
            video_url_result = await self._get_video_url()
            thumbnail_url = await self._get_thumbnail_url()
            error_message = await self._get_error_message()
            
            current_page_url = await self.browser.get_current_url()
            
            self.log_info(f"Video status: {status.value}, progress: {progress}%")
            
            return ActionResult.success_result(
                action=self.ACTION_NAME,
                data={
                    "video_id": video_id,
                    "status": status.value,
                    "progress": progress,
                    "video_url": video_url_result,
                    "thumbnail_url": thumbnail_url,
                    "page_url": current_page_url,
                    "error": error_message,
                    "is_ready": status == VideoStatus.COMPLETED,
                    "is_failed": status == VideoStatus.FAILED,
                    "is_processing": status == VideoStatus.PROCESSING,
                }
            )
            
        except Exception as e:
            self.log_error(f"Failed to check status: {str(e)}")
            return ActionResult.error_result(
                action=self.ACTION_NAME,
                error=str(e)
            )
    
    async def _parse_status(self) -> VideoStatus:
        """Parse video status từ UI elements"""
        # Check completed indicators
        for selector in Selectors.Video.STATUS_COMPLETED:
            try:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    return VideoStatus.COMPLETED
            except Exception:
                continue
        
        # Check failed indicators
        for selector in Selectors.Video.STATUS_FAILED:
            try:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    return VideoStatus.FAILED
            except Exception:
                continue
        
        # Check processing indicators
        for selector in Selectors.Video.STATUS_PROCESSING:
            try:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    return VideoStatus.PROCESSING
            except Exception:
                continue
        
        # Check nếu có video ready (download button visible)
        for selector in Selectors.Video.DOWNLOAD_BUTTON:
            try:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    return VideoStatus.COMPLETED
            except Exception:
                continue
        
        # Check loading spinner
        for selector in Selectors.Common.LOADING_SPINNER:
            try:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    return VideoStatus.PROCESSING
            except Exception:
                continue
        
        # Default: pending
        return VideoStatus.PENDING
    
    async def _parse_progress(self) -> int:
        """Parse progress percentage từ UI"""
        # Thử lấy từ progress bar
        for selector in Selectors.Video.PROGRESS_BAR:
            try:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    # Thử lấy aria-valuenow
                    value = await locator.get_attribute("aria-valuenow")
                    if value:
                        return int(float(value))
                    
                    # Thử lấy style width
                    style = await locator.get_attribute("style")
                    if style:
                        match = re.search(r'width:\s*(\d+)%', style)
                        if match:
                            return int(match.group(1))
            except Exception:
                continue
        
        # Thử lấy từ text
        for selector in Selectors.Video.PROGRESS_TEXT:
            try:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    text = await locator.text_content()
                    if text:
                        match = re.search(r'(\d+)%', text)
                        if match:
                            return int(match.group(1))
            except Exception:
                continue
        
        # Không tìm thấy progress
        return 0
    
    async def _get_video_url(self) -> Optional[str]:
        """Lấy video URL nếu đã ready"""
        try:
            video = self.page.locator("video")
            if await video.count() > 0:
                src = await video.get_attribute("src")
                if src and src.startswith("http"):
                    return src
            
            source = self.page.locator("video source")
            if await source.count() > 0:
                src = await source.get_attribute("src")
                if src and src.startswith("http"):
                    return src
        except Exception:
            pass
        
        return None
    
    async def _get_thumbnail_url(self) -> Optional[str]:
        """Lấy thumbnail URL"""
        try:
            # Thử lấy từ video poster
            video = self.page.locator("video")
            if await video.count() > 0:
                poster = await video.get_attribute("poster")
                if poster:
                    return poster
            
            # Thử lấy từ thumbnail image
            thumbnail = self.page.locator("[data-testid='thumbnail'], .thumbnail, .video-thumbnail")
            if await thumbnail.count() > 0:
                src = await thumbnail.get_attribute("src")
                if src:
                    return src
        except Exception:
            pass
        
        return None
    
    async def _get_error_message(self) -> Optional[str]:
        """Lấy error message nếu có"""
        for selector in Selectors.Common.ERROR_MESSAGE:
            try:
                locator = self.page.locator(selector)
                if await locator.count() > 0:
                    text = await locator.text_content()
                    if text:
                        return text.strip()
            except Exception:
                continue
        
        return None
