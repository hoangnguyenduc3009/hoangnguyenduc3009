"""
Logger utility cho VEO Automation

Cung cấp structured logging dạng JSON để Rust backend
có thể parse và emit events đến frontend.
"""

import json
import sys
from datetime import datetime
from enum import Enum
from typing import Any, Optional


class LogLevel(str, Enum):
    """Log levels"""
    DEBUG = "debug"
    INFO = "info"
    WARN = "warn"
    ERROR = "error"


class Logger:
    """
    Structured JSON logger.
    
    Output format được thiết kế để Rust backend parse
    và emit tới frontend qua Tauri events.
    """
    
    def __init__(
        self,
        component: str = "veo_automation",
        min_level: LogLevel = LogLevel.INFO
    ):
        """
        Khởi tạo logger.
        
        Args:
            component: Tên component để identify trong logs
            min_level: Minimum log level để output
        """
        self.component = component
        self.min_level = min_level
        
        # Level priority for filtering
        self._level_priority = {
            LogLevel.DEBUG: 0,
            LogLevel.INFO: 1,
            LogLevel.WARN: 2,
            LogLevel.ERROR: 3,
        }
    
    def _should_log(self, level: LogLevel) -> bool:
        """Check if level should be logged"""
        return (
            self._level_priority[level] >= 
            self._level_priority[self.min_level]
        )
    
    def _format_message(
        self,
        level: LogLevel,
        message: str,
        action: Optional[str] = None,
        **extra: Any
    ) -> str:
        """Format log message as JSON"""
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "level": level.value,
            "component": self.component,
            "message": message,
        }
        
        if action:
            log_entry["action"] = action
        
        # Add extra fields
        if extra:
            log_entry["data"] = extra
        
        return json.dumps(log_entry, ensure_ascii=False)
    
    def log(
        self,
        level: LogLevel,
        message: str,
        action: Optional[str] = None,
        **extra: Any
    ) -> None:
        """
        Log message với level và optional data.
        
        Args:
            level: Log level
            message: Log message
            action: Optional action name
            **extra: Additional data fields
        """
        if not self._should_log(level):
            return
        
        formatted = self._format_message(level, message, action, **extra)
        print(formatted, flush=True)
    
    def debug(self, message: str, **extra: Any) -> None:
        """Log debug message"""
        self.log(LogLevel.DEBUG, message, **extra)
    
    def info(self, message: str, **extra: Any) -> None:
        """Log info message"""
        self.log(LogLevel.INFO, message, **extra)
    
    def warn(self, message: str, **extra: Any) -> None:
        """Log warning message"""
        self.log(LogLevel.WARN, message, **extra)
    
    def error(self, message: str, **extra: Any) -> None:
        """Log error message"""
        self.log(LogLevel.ERROR, message, **extra)
    
    def action_start(self, action: str, **params: Any) -> None:
        """Log action start"""
        self.info(f"Starting action: {action}", action=action, params=params)
    
    def action_success(self, action: str, **data: Any) -> None:
        """Log action success"""
        self.info(f"Action completed: {action}", action=action, **data)
    
    def action_error(self, action: str, error: str, **data: Any) -> None:
        """Log action error"""
        self.error(f"Action failed: {action} - {error}", action=action, error=error, **data)
    
    def progress(
        self,
        action: str,
        current: int,
        total: int,
        message: Optional[str] = None
    ) -> None:
        """Log progress update"""
        percent = int((current / total) * 100) if total > 0 else 0
        self.info(
            message or f"Progress: {percent}%",
            action=action,
            progress=percent,
            current=current,
            total=total
        )


# Global logger instance
_logger: Optional[Logger] = None


def get_logger(component: str = "veo_automation") -> Logger:
    """Get or create global logger instance"""
    global _logger
    if _logger is None or _logger.component != component:
        _logger = Logger(component=component)
    return _logger


def set_log_level(level: LogLevel) -> None:
    """Set global log level"""
    global _logger
    if _logger:
        _logger.min_level = level


# Convenience functions
def log_info(message: str, **extra: Any) -> None:
    """Log info using global logger"""
    get_logger().info(message, **extra)


def log_error(message: str, **extra: Any) -> None:
    """Log error using global logger"""
    get_logger().error(message, **extra)


def log_warn(message: str, **extra: Any) -> None:
    """Log warning using global logger"""
    get_logger().warn(message, **extra)


def log_debug(message: str, **extra: Any) -> None:
    """Log debug using global logger"""
    get_logger().debug(message, **extra)
