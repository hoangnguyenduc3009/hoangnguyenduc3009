"""
CSS/XPath Selectors cho VEO3 UI

Tập trung tất cả selectors vào một file để dễ maintain
khi Google thay đổi UI.
"""


class Selectors:
    """
    Centralized CSS/XPath selectors cho VEO3 website.
    
    Mỗi element có multiple fallback selectors để tăng reliability
    khi UI thay đổi.
    """
    
    # ========== LOGIN PAGE ==========
    
    class Login:
        """Selectors cho login flow"""
        
        # Nút "Create with Flow" hoặc "Sign in"
        CREATE_WITH_FLOW = [
            "button:has(span:text('Create with Flow'))",
            "span:text('Create with Flow')",
            "button:has-text('Create with Flow')",
            "[data-testid='create-flow-button']",
            "a:has-text('Create with Flow')",
        ]
        
        SIGN_IN_BUTTON = [
            "button:has-text('Sign in')",
            "a:has-text('Sign in')",
            "[data-testid='sign-in-button']",
            "button:has(span:text('Sign in'))",
        ]
        
        # Google OAuth elements
        GOOGLE_EMAIL_INPUT = [
            "input[type='email']",
            "#identifierId",
            "input[name='identifier']",
        ]
        
        GOOGLE_PASSWORD_INPUT = [
            "input[type='password']",
            "input[name='password']",
            "#password input",
        ]
        
        GOOGLE_NEXT_BUTTON = [
            "#identifierNext button",
            "button:has-text('Next')",
            "[data-testid='next-button']",
        ]
        
        # User avatar (indicator đã đăng nhập)
        USER_AVATAR = [
            "[data-testid='user-avatar']",
            "img[alt*='profile']",
            "img[alt*='hồ sơ']",  # Tiếng Việt: "Hình ảnh hồ sơ người dùng"
            ".user-avatar",
            "[aria-label*='Account']",
        ]
        
        # User info từ account menu/dialog
        # Dựa vào cấu trúc DOM: Google Logo -> sibling div chứa user info
        # <div> Google Logo </div>
        # <div> <img avatar> <div> <span>Name</span> <span>Email</span> </div> </div>
        USER_NAME = [
            # Tìm span đầu tiên trong div kế tiếp của Google Logo container
            "img[alt='Google Logo'] ~ div > div > span:first-child",
            "img[alt='Google Logo'] ~ div span:first-of-type",
            # Fallback: tìm span chứa text không có @ (tên, không phải email)
            "div[role='dialog'] img[alt*='hồ sơ'] ~ div span:first-child",
            "div[role='dialog'] img[alt*='profile'] ~ div span:first-child",
        ]
        
        USER_EMAIL = [
            # Tìm span thứ hai trong div kế tiếp của Google Logo container
            "img[alt='Google Logo'] ~ div > div > span:last-child",
            "img[alt='Google Logo'] ~ div span:nth-of-type(2)",
            # Fallback: tìm span chứa @
            "div[role='dialog'] img[alt*='hồ sơ'] ~ div span:last-child",
            "div[role='dialog'] img[alt*='profile'] ~ div span:last-child",
        ]
        
        # Account menu button (click để mở dialog với user info)
        ACCOUNT_MENU_BUTTON = [
            "img[alt*='hồ sơ']",  # Tiếng Việt: "Hình ảnh hồ sơ người dùng"
            "img[alt*='profile']",
            "button[aria-label*='Account']",
            "[data-testid='account-button']",
        ]
    
    # ========== PROJECT PAGE ==========
    
    class Project:
        """Selectors cho project management"""
        
        # Nút tạo project mới
        CREATE_PROJECT = [
            "button:has-text('New project')",
            "button:has-text('Create project')",
            "[data-testid='create-project-button']",
            "a:has-text('New project')",
        ]
        
        # Input tên project
        PROJECT_NAME_INPUT = [
            "input[placeholder*='project name']",
            "input[name='projectName']",
            "[data-testid='project-name-input']",
            "input[aria-label*='project name']",
        ]
        
        # List projects
        PROJECT_LIST = [
            "[data-testid='project-list']",
            ".project-list",
            "[role='list']",
        ]
        
        PROJECT_ITEM = [
            "[data-testid='project-item']",
            ".project-item",
            "[role='listitem']",
        ]
        
        # Project settings
        SETTINGS_BUTTON = [
            "button:has-text('Settings')",
            "[data-testid='settings-button']",
            "button[aria-label='Settings']",
        ]
        
        # Aspect ratio selector
        ASPECT_RATIO_DROPDOWN = [
            "[data-testid='aspect-ratio-select']",
            "select[name='aspectRatio']",
            "button:has-text('Aspect ratio')",
        ]
        
        ASPECT_RATIO_16_9 = [
            "option[value='16:9']",
            "[data-value='16:9']",
            "li:has-text('16:9')",
        ]
        
        ASPECT_RATIO_9_16 = [
            "option[value='9:16']",
            "[data-value='9:16']",
            "li:has-text('9:16')",
        ]
        
        ASPECT_RATIO_1_1 = [
            "option[value='1:1']",
            "[data-value='1:1']",
            "li:has-text('1:1')",
        ]
        
        # Style selector
        STYLE_DROPDOWN = [
            "[data-testid='style-select']",
            "select[name='style']",
            "button:has-text('Style')",
        ]
    
    # ========== PROMPT PAGE ==========
    
    class Prompt:
        """Selectors cho prompt input và generation"""
        
        # Textarea nhập prompt
        PROMPT_INPUT = [
            "textarea[placeholder*='Describe']",
            "textarea[name='prompt']",
            "[data-testid='prompt-input']",
            "textarea[aria-label*='prompt']",
            ".prompt-textarea",
        ]
        
        # Nút generate
        GENERATE_BUTTON = [
            "button:has-text('Generate')",
            "button:has-text('Create')",
            "[data-testid='generate-button']",
            "button[type='submit']",
        ]
        
        # Duration selector
        DURATION_SLIDER = [
            "input[type='range']",
            "[data-testid='duration-slider']",
            ".duration-slider",
        ]
        
        DURATION_INPUT = [
            "input[type='number'][name='duration']",
            "[data-testid='duration-input']",
        ]
        
        # Negative prompt
        NEGATIVE_PROMPT_TOGGLE = [
            "button:has-text('Negative prompt')",
            "[data-testid='negative-prompt-toggle']",
        ]
        
        NEGATIVE_PROMPT_INPUT = [
            "textarea[name='negativePrompt']",
            "[data-testid='negative-prompt-input']",
        ]
        
        # Seed input
        SEED_INPUT = [
            "input[name='seed']",
            "[data-testid='seed-input']",
            "input[placeholder*='seed']",
        ]
    
    # ========== VIDEO PLAYER & RESULTS ==========
    
    class Video:
        """Selectors cho video player và kết quả"""
        
        # Video container
        VIDEO_CONTAINER = [
            "[data-testid='video-container']",
            ".video-container",
            "video",
        ]
        
        VIDEO_PLAYER = [
            "video",
            "[data-testid='video-player']",
            ".video-player",
        ]
        
        # Progress indicator
        PROGRESS_BAR = [
            "[data-testid='progress-bar']",
            ".progress-bar",
            "[role='progressbar']",
        ]
        
        PROGRESS_TEXT = [
            "[data-testid='progress-text']",
            ".progress-text",
            "span:has-text('%')",
        ]
        
        # Status indicators
        STATUS_PROCESSING = [
            "[data-testid='status-processing']",
            ":text('Processing')",
            ":text('Generating')",
        ]
        
        STATUS_COMPLETED = [
            "[data-testid='status-completed']",
            ":text('Complete')",
            ":text('Ready')",
        ]
        
        STATUS_FAILED = [
            "[data-testid='status-failed']",
            ":text('Failed')",
            ":text('Error')",
        ]
        
        # Download button
        DOWNLOAD_BUTTON = [
            "button:has-text('Download')",
            "[data-testid='download-button']",
            "a[download]",
            "button[aria-label='Download']",
        ]
        
        # Extend video button
        EXTEND_BUTTON = [
            "button:has-text('Extend')",
            "[data-testid='extend-button']",
            "button:has-text('Continue')",
        ]
    
    # ========== EXTEND VIDEO ==========
    
    class Extend:
        """Selectors cho extend video flow"""
        
        # Direction buttons
        EXTEND_FORWARD = [
            "button:has-text('Forward')",
            "[data-testid='extend-forward']",
            "button[value='forward']",
        ]
        
        EXTEND_BACKWARD = [
            "button:has-text('Backward')",
            "[data-testid='extend-backward']",
            "button[value='backward']",
        ]
        
        # Extend prompt input
        EXTEND_PROMPT_INPUT = [
            "textarea[name='extendPrompt']",
            "[data-testid='extend-prompt-input']",
            "textarea[placeholder*='extend']",
        ]
        
        # Confirm extend
        CONFIRM_EXTEND = [
            "button:has-text('Extend video')",
            "[data-testid='confirm-extend']",
            "button[type='submit']",
        ]
    
    # ========== COMMON ==========
    
    class Common:
        """Common selectors dùng chung"""
        
        # Loading indicators
        LOADING_SPINNER = [
            "[data-testid='loading']",
            ".loading-spinner",
            "[role='progressbar']",
            ".spinner",
        ]
        
        # Error messages
        ERROR_MESSAGE = [
            "[data-testid='error-message']",
            ".error-message",
            "[role='alert']",
            ".alert-error",
        ]
        
        # Success messages
        SUCCESS_MESSAGE = [
            "[data-testid='success-message']",
            ".success-message",
            ".alert-success",
        ]
        
        # Modal/Dialog
        MODAL = [
            "[role='dialog']",
            ".modal",
            "[data-testid='modal']",
        ]
        
        MODAL_CLOSE = [
            "button[aria-label='Close']",
            ".modal-close",
            "button:has-text('Close')",
        ]
        
        # Confirm/Cancel buttons
        CONFIRM_BUTTON = [
            "button:has-text('Confirm')",
            "button:has-text('OK')",
            "button:has-text('Yes')",
            "[data-testid='confirm-button']",
        ]
        
        CANCEL_BUTTON = [
            "button:has-text('Cancel')",
            "button:has-text('No')",
            "[data-testid='cancel-button']",
        ]
