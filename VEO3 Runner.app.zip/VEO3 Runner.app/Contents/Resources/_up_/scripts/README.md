# VEO Automation Scripts

Browser automation package cho VEO3 video generation.

## Cấu trúc thư mục

```
scripts/
├── main.py                 # CLI entry point
├── README.md
└── veo_automation/         # Main automation package
    ├── __init__.py
    ├── browser.py          # BrowserManager - session & cookie management
    ├── base.py             # BaseAction, ActionResult classes
    ├── types.py            # Python dataclasses (mirror TS types)
    ├── actions/
    │   ├── __init__.py
    │   ├── login.py        # LoginAction - Google OAuth
    │   ├── project.py      # CreateProject, GoToProject
    │   ├── prompt.py       # SubmitPromptAction
    │   ├── extend.py       # ExtendVideoAction
    │   ├── download.py     # DownloadVideoAction
    │   └── status.py       # CheckStatusAction
    └── utils/
        ├── __init__.py
        ├── selectors.py    # CSS selectors cho VEO3 UI
        └── logger.py       # JSON structured logging
```

## Cài đặt

```bash
# Trong thư mục gốc project
python -m venv .venv
source .venv/bin/activate
pip install playwright
playwright install chromium
```

## Sử dụng CLI

### Login

```bash
python scripts/main.py --action login
# Headless mode (nếu đã có cookies):
python scripts/main.py --action login --headless
```

### Tạo Project

```bash
python scripts/main.py --action create_project --data '{"name": "My Project", "aspect_ratio": "16:9", "style": "cinematic"}'
```

### Submit Prompt

```bash
python scripts/main.py --action submit_prompt --data '{"prompt": "A cat playing piano", "duration": 8}'
```

### Check Video Status

```bash
python scripts/main.py --action check_status --data '{"video_id": "abc123"}'
```

### Extend Video

```bash
python scripts/main.py --action extend_video --data '{"video_id": "abc123", "direction": "forward", "extend_prompt": "Continue the scene..."}'
```

### Download Video

```bash
python scripts/main.py --action download --data '{"video_id": "abc123", "output_path": "/path/to/video.mp4"}'
```

## Actions

| Action | Mô tả | Parameters |
|--------|-------|------------|
| `login` | Đăng nhập Google OAuth | `auto_click_signin`, `wait_for_manual_login` |
| `create_project` | Tạo project mới | `name`, `aspect_ratio`, `style` |
| `goto_project` | Navigate đến project | `project_id`, `project_url`, `project_name` |
| `submit_prompt` | Generate video | `prompt`, `aspect_ratio`, `style`, `duration`, `seed`, `negative_prompt` |
| `check_status` | Kiểm tra trạng thái | `video_id` |
| `extend_video` | Extend video | `video_id`, `direction`, `extend_prompt`, `duration` |
| `download` | Tải video | `video_id`, `output_path`, `quality` |

## Cookie Persistence

Cookies được lưu tại: `~/.veo-runner/browser-data/cookies.json`

Sau khi login lần đầu, cookies sẽ được restore tự động cho các lần sau.

## Output Format

Output là JSON với markers để Rust backend parse:

```
===RESULT_START===
{
  "success": true,
  "action": "login",
  "data": { ... },
  "error": null,
  "timestamp": "2026-01-05T10:30:00"
}
===RESULT_END===
```

## Development

```bash
# Run với debug logging
python scripts/main.py --action login --debug

# Không restore cookies (fresh session)
python scripts/main.py --action login --no-restore-cookies

# Custom data directory
python scripts/main.py --action login --data-dir /custom/path
```
