#!/usr/bin/env python3
"""
VEO Automation CLI - Entry point cho browser automation

Usage:
    python main.py --action login [--headless] [--cookies PATH]
    python main.py --action create_project --data '{"name": "My Project"}'
    python main.py --action submit_prompt --data '{"prompt": "A cat..."}'
    python main.py --action check_status --data '{"video_id": "abc123"}'
    python main.py --action extend_video --data '{"video_id": "abc123", "direction": "forward"}'
    python main.py --action download --data '{"video_id": "abc123", "output_path": "/path/to/video.mp4"}'
    
Actions:
    login           - Đăng nhập Google OAuth
    create_project  - Tạo project mới trên VEO3
    goto_project    - Navigate đến project có sẵn
    submit_prompt   - Submit prompt để generate video
    check_status    - Check trạng thái video generation
    extend_video    - Extend video hiện có
    download        - Download video về local
    session_status  - Check trạng thái browser session
"""

import argparse
import asyncio
import json
import sys
from pathlib import Path
from typing import Optional, Dict, Any

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent))

from veo_automation import (
    BrowserManager,
    ActionResult,
    LoginAction,
    CreateProjectAction,
    GoToProjectAction,
    SubmitPromptAction,
    ExtendVideoAction,
    DownloadVideoAction,
    CheckStatusAction,
)
from veo_automation.utils.logger import Logger, LogLevel


# Action mapping
ACTION_MAP = {
    "login": LoginAction,
    "create_project": CreateProjectAction,
    "goto_project": GoToProjectAction,
    "submit_prompt": SubmitPromptAction,
    "check_status": CheckStatusAction,
    "extend_video": ExtendVideoAction,
    "download": DownloadVideoAction,
}

# Special actions không cần browser
SPECIAL_ACTIONS = ["session_status", "install_browser"]


def parse_args() -> argparse.Namespace:
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(
        description="VEO Automation CLI - Browser automation for VEO3",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )
    
    parser.add_argument(
        "--action", "-a",
        required=True,
        choices=list(ACTION_MAP.keys()) + SPECIAL_ACTIONS,
        help="Action to perform"
    )
    
    parser.add_argument(
        "--data", "-d",
        type=str,
        default="{}",
        help="JSON data for the action"
    )
    
    parser.add_argument(
        "--headless",
        action="store_true",
        help="Run browser in headless mode (no UI)"
    )
    
    parser.add_argument(
        "--cookies", "-c",
        type=str,
        help="Path to cookies file for session persistence"
    )
    
    parser.add_argument(
        "--data-dir",
        type=str,
        help="Directory for browser data storage"
    )
    
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging"
    )
    
    parser.add_argument(
        "--no-restore-cookies",
        action="store_true",
        help="Don't restore cookies from saved file"
    )
    
    return parser.parse_args()


def parse_data(data_str: str) -> Dict[str, Any]:
    """Parse JSON data string"""
    try:
        return json.loads(data_str)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON data: {e}")


async def run_action(
    action_name: str,
    data: Dict[str, Any],
    headless: bool = False,
    cookies_path: Optional[str] = None,
    data_dir: Optional[str] = None,
    restore_cookies: bool = True,
) -> ActionResult:
    """
    Run automation action.
    
    Args:
        action_name: Tên action cần chạy
        data: Data parameters cho action
        headless: Chạy browser ẩn
        cookies_path: Path đến file cookies
        data_dir: Directory lưu browser data
        restore_cookies: Restore cookies từ file đã lưu
        
    Returns:
        ActionResult từ action
    """
    logger = Logger(component="main")
    
    # Handle install_browser specially (không cần browser instance)
    if action_name == "install_browser":
        return await install_browser_action(data, logger)
    
    # Handle session_status specially (không cần browser)
    if action_name == "session_status":
        browser = BrowserManager(
            headless=headless,
            data_dir=Path(data_dir) if data_dir else None,
            cookies_file=cookies_path,
        )
        
        status = browser.get_session_status()
        return ActionResult.success_result(
            action="session_status",
            data=status
        )
    
    # Validate action
    if action_name not in ACTION_MAP:
        return ActionResult.error_result(
            action=action_name,
            error=f"Unknown action: {action_name}"
        )
    
    # Create browser manager
    browser = BrowserManager(
        headless=headless,
        data_dir=Path(data_dir) if data_dir else None,
        cookies_file=cookies_path,
    )
    
    try:
        # Start browser
        await browser.start(restore_cookies=restore_cookies)
        
        # Create action instance
        action_class = ACTION_MAP[action_name]
        action = action_class(browser)
        
        # Execute action
        result = await action.safe_execute(**data)
        
        # Nếu login thành công, giữ browser mở để user làm việc tiếp
        # Các action khác sẽ tự đóng browser
        if action_name == "login" and result.success:
            # Lưu cookies nhưng KHÔNG đóng browser
            await browser.save_cookies()
            
            # QUAN TRỌNG: Output result TRƯỚC KHI vào vòng lặp giữ browser
            # Để Rust backend nhận được kết quả ngay
            print(result.to_marked_json())
            sys.stdout.flush()  # Đảm bảo output được gửi ngay
            
            logger.info("Browser kept open for further operations")
            
            # Đợi vô hạn cho đến khi process bị kill
            # Return sẽ không bao giờ xảy ra, result đã được print ở trên
            try:
                while True:
                    await asyncio.sleep(60)
            except asyncio.CancelledError:
                pass
            
            # Không return ở đây vì đã print result rồi
            return None
        
        return result
        
    except Exception as e:
        logger.error(f"Action failed: {str(e)}")
        return ActionResult.error_result(
            action=action_name,
            error=str(e)
        )
        
    finally:
        # Cleanup - save cookies và close browser (trừ login action)
        if action_name != "login":
            await browser.stop(save_cookies=True)


async def install_browser_action(data: Dict[str, Any], logger) -> ActionResult:
    """
    Cài đặt Playwright browser.
    
    Args:
        data: {"browser": "chromium"} - loại browser cần cài
        logger: Logger instance
        
    Returns:
        ActionResult
    """
    import subprocess
    
    browser_type = data.get("browser", "chromium")
    logger.info(f"Installing Playwright browser: {browser_type}")
    
    try:
        # Chạy playwright install
        result = subprocess.run(
            [sys.executable, "-m", "playwright", "install", browser_type],
            capture_output=True,
            text=True,
            timeout=300  # 5 phút timeout
        )
        
        if result.returncode == 0:
            logger.info(f"Browser {browser_type} installed successfully")
            return ActionResult.success_result(
                action="install_browser",
                data={
                    "browser": browser_type,
                    "message": f"{browser_type} installed successfully"
                }
            )
        else:
            error_msg = result.stderr or result.stdout or "Unknown error"
            logger.error(f"Failed to install browser: {error_msg}")
            return ActionResult.error_result(
                action="install_browser",
                error=f"Failed to install {browser_type}: {error_msg}"
            )
            
    except subprocess.TimeoutExpired:
        return ActionResult.error_result(
            action="install_browser",
            error="Installation timed out (>5 minutes)"
        )
    except Exception as e:
        return ActionResult.error_result(
            action="install_browser",
            error=str(e)
        )


def main():
    """Main entry point"""
    args = parse_args()
    
    # Setup logging
    logger = Logger(
        component="main",
        min_level=LogLevel.DEBUG if args.debug else LogLevel.INFO
    )
    
    logger.info(f"Starting VEO Automation: action={args.action}")
    
    try:
        # Parse data
        data = parse_data(args.data)
        
        # Run action
        result = asyncio.run(run_action(
            action_name=args.action,
            data=data,
            headless=args.headless,
            cookies_path=args.cookies,
            data_dir=args.data_dir,
            restore_cookies=not args.no_restore_cookies,
        ))
        
        # Output result với markers (trừ login action vì đã print trong run_action)
        if result is not None:
            print(result.to_marked_json())
            sys.exit(0 if result.success else 1)
        else:
            # Login action đã tự print và giữ browser mở
            sys.exit(0)
        
    except Exception as e:
        logger.error(f"Fatal error: {str(e)}")
        
        # Output error result
        error_result = ActionResult.error_result(
            action=args.action,
            error=str(e)
        )
        print(error_result.to_marked_json())
        
        sys.exit(1)


if __name__ == "__main__":
    main()
